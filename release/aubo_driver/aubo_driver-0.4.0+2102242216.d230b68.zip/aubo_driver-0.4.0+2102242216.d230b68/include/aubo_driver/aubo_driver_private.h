#ifndef AUBO_DRIVER_PRIVATE_H
#define AUBO_DRIVER_PRIVATE_H
#include <vector>

namespace arcs {
namespace aubo_driver {
class AuboDriverPrivate
{
public:
    virtual ~AuboDriverPrivate() = default;

    // 进入配置模式
    virtual bool enterConfigMode() = 0;
    virtual bool exitConfigMode() = 0;

    // DH参数补偿
    virtual bool setKinematicsParams(const std::vector<double> &dA,
                                     const std::vector<double> &dD,
                                     const std::vector<double> &dAlpha,
                                     const std::vector<double> &dTheta,
                                     const std::vector<double> &dBeta) = 0;

    // 动力学参数
    virtual bool setDynamicsParams(
        const std::vector<double> &K,    // motor torque constant
        const std::vector<double> &IA,   // rotor inertia
        const std::vector<double> &M,    // link mass
        const std::vector<double> &MXYZ, // center of mass
        const std::vector<double> &IXYZ, // Inertia parameter
        const std::vector<double> &CB    // current bias
        ) = 0;

    // 摩擦力模型
    virtual bool setJointFrictionModel(
        const std::vector<double> &FL,        // load friction compensation
        const std::vector<double> &FR,        // reserved friction compensation
        const std::vector<double> &tmp_a,     // tmp_coefficient_a
        const std::vector<double> &tmp_b,     // tmp_coefficient_b
        const std::vector<double> &posvel_a1, // positive_vel_a1
        const std::vector<double> &posvel_b1, // positive_vel_b1
        const std::vector<double> &posvel_a2, // positive_vel_a2
        const std::vector<double> &posvel_b2, // positive_vel_b2
        const std::vector<double> &posvel_c2, // positive_vel_c2
        const std::vector<double> &negvel_a1, // negative_vel_a1
        const std::vector<double> &negvel_b1, // negative_vel_b1
        const std::vector<double> &negvel_a2, // negative_vel_a2
        const std::vector<double> &negvel_b2, // negative_vel_b2
        const std::vector<double> &negvel_c2  // negative_vel_c2
        ) = 0;

    // 拖动示教参数
    virtual bool setHandGuideParams(
        const std::vector<double> &FP,        // friction compensation percent
        const std::vector<double> &FD,        // damp coefficient
        const std::vector<double> &FK,        // stiffness coefficient
        const std::vector<double> &FM,        // mass coefficient
        const std::vector<double> &pos_limit, // position limit
        const std::vector<double> &velocity_limit,    // velocity limit
        const std::vector<double> &acceleration_limit // acceleration limit
        ) = 0;
};
} // namespace aubo_driver
} // namespace arcs

#endif // AUBO_DRIVER_PRIVATE_H
