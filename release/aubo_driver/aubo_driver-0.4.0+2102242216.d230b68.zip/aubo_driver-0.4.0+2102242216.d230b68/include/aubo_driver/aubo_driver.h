// Copyright 2020 Aubo Robotics
// License: All rights reserved by Aubo Robotics.
// Author: Lou Wei(louwei@aubo-robotics.cn)
// Maintainer:
//
// 本文件是aubo机器人控制器软件用户开发API,
// 通过本文件提供的接口，用户可以非常方便的通过socket
// tcp/udp连接到aubo机器人控制器软件
// 使用此版本API的基本步骤为:
// 1. 通过工厂函数(createAuboDriver)创建接口实例
// 2. 连接到服务器
// 3. 提供用户名和密码登录
// 4. 设置RTDE输出(相对于服务器而言)菜单
// 5. 开始RTDE传输
// 6. 正常操作: 机器人控制指令、运动控制指令、读取机器人状态
// 7. 等待断开与服务器的连接

// 以下为简单的示例:
// clang-format off
// auto aubo_driver = createAuboDriver();
// std::map<std::string, std::string> list = aubo_driver->rtdeGetOutputListMap();
// std::cout << "RTDE Output: " << std::endl;
// for (auto it : list) {
//    std::cout << it.first << ", " << it.second << std::endl;
// }
// aubo_driver->connectToServer("127.0.0.1", 30001， 100);
// if (aubo_driver->login("user", "111", 50)) {
//    std::cout << "user login succeed" << std::endl;
//    // aubo_driver->setRobotPowerOn();
//    std::vector<std::string> names;
//    names.push_back("actual_q");

//    aubo_driver->rtdeSetOutputRecipe(0, names, 200);
//    aubo_driver->rtdeStartCommunication(0);
//    // aubo_driver->logout();
// } else {
//    std::cout << "user login failed" << std::endl;
// }
// aubo_driver->waitForTerminate();
// clang-format on

#ifndef AUBO_DRIVER_H
#define AUBO_DRIVER_H

#include <string>
#include <cstdint>
#include <vector>
#include <map>
#include <functional>
#include <memory>

#include <aubo_driver/exceptions.h>

#if defined(ARCS_USE_DLLS)
#if defined(_MSC_VER)
#ifdef LIBARCS_EXPORTS
#define ARCS_EXPORT __declspec(dllexport)
#define ARCS_EXPORT_TEMPLATE_DECLARE
#define ARCS_EXPORT_TEMPLATE_DEFINE __declspec(dllexport)
#else
#define ARCS_EXPORT __declspec(dllimport)
#define ARCS_EXPORT_TEMPLATE_DECLARE
#define ARCS_EXPORT_TEMPLATE_DEFINE __declspec(dllimport)
#endif
#else // defined(_MSC_VER)
#ifdef LIBARCS_EXPORTS
#define ARCS_EXPORT                  __attribute__((visibility("default")))
#define ARCS_EXPORT_TEMPLATE_DECLARE __attribute__((visibility("default")))
#define ARCS_EXPORT_TEMPLATE_DEFINE
#else
#define ARCS_EXPORT
#define ARCS_EXPORT_TEMPLATE_DECLARE
#define ARCS_EXPORT_TEMPLATE_DEFINE
#endif
#endif
#else // defined(ARCS_USE_DLLS)
#define ARCS_EXPORT
#define ARCS_EXPORT_TEMPLATE_DECLARE
#define ARCS_EXPORT_TEMPLATE_DEFINE
#endif

namespace arcs {
namespace aubo_driver {
// 机器人控制模式
enum class RobotControlMode : int
{
    None = -1,
    Position = 0,
    Teach = 1,
    Force = 2,
    Torque = 3,
};

// 机器人运行状态
enum class RobotMode : int
{
    NoController = 0,
    Disconnected = 1,  // 没有连接到机械臂本体
    ConfirmSafety = 2, // 正在进行安全配置，断电状态下进行
    Booting = 3,       // 机械臂本体正在上电初始化
    PowerOff = 4,      // 机械臂本体处于断电状态
    PowerOn = 5,       //
    Idle = 6, // 机械臂上电成功，刹车暂未松开(抱死)，电机不通电
    BackDrive = 7,         // 反向驱动：刹车松开，电机不通电
    Running = 8,           // 机械臂刹车松开，运行模式
    BrakeReleasing = 9,    // 机械臂上电成功，刹车松开
    BrakeLocking = 10,     // 机械臂上电成功，刹车暂未松开
    UpdatingFirmware = 11, // 固件升级
    Error = 12,
};

// 关节运行状态
enum class JointMode : int
{
    Reset = 235,
    ShuttingDown = 236,
    BackDrive = 238,
    PowerOff = 239,
    ReadyForPowerOff = 240,
    NotResponding = 245,
    MotorInstallation = 246,
    Booting = 247,
    Violation = 251,
    Fault = 252,
    Running = 253,
    Idle = 255,
};

// 安全状态
enum class SafetyMode : int
{
    Normal = 1,
    Reduced = 2,
    ProtectiveStop = 3,
    Recovery = 4,
    SafeguardStop = 5,
    SystemEmergencyStop = 6,
    RobotEmergencyStop = 7,
    Violation = 8,
    Fault = 9,
    ValidateJointId = 10,
    Undefined = 11,
};

enum class SafetyModeStatus : int
{
    Normal = 1,
    Reduced = 2,
    ProtectiveStop = 3,
    Recovery = 4,
    SafeguardStop = 5,
    SystemEmergencyStop = 6,
    RobotEmergencyStop = 7,
    Violation = 8,
    Fault = 9,
    ValidateJointId = 10,
    Undefined = 11,
    AutomaticSafeguardStop = 12,
    ThreePositionEnablingStop = 13
};

enum class ReportLevel : int
{
    Debug = 0,
    Info = 1,
    Warning = 2,
    Violation = 3,
    Fault = 4,
    DevlDebug = 128,
    DevlInfo = 129,
    DevlWarning = 130,
    DevlViolation = 131,
    DevlFault = 132,
};

enum class RequestedType : int
{
    Boolean = 0,
    Integer = 1,
    Double = 2,
    String = 3,
    Pose = 4,
    JointVector = 5,
    Waypoint = 6,
    Expression = 7,
    None = 8,
};

enum class ValueType : int
{
    None = 0,
    ConstString = 3,
    VarString = 4,
    List = 5,
    Pose = 10,
    Bool = 12,
    Num = 13,
    Int = 14,
    Double = 15,
};

// 运行时状态
enum class RuntimeState : int
{
    Stopping = 0,
    Stopped = 1,
    Playing = 2,
    Pausing = 3,
    Paused = 4,
    Resuming = 5,
    Retracting = 6,
};

// 操作模式
enum class OperationalMode : int
{
    Disabled,
    Automatic,
    Manual,
};

// 用户角色
enum class UserRole : int
{
    None,
    Administrator,
    Developer,
    Integrator,
    Operator
};

// 机器人类型
enum RobotType : int
{
    Unkown = -1,
    I3,
    I5,
    I7,
    I10
};

// 参考坐标系类型
enum CoordType : int
{
    Base = 0,  // 机器人基座坐标系
    End = 1,   // 机器人末端坐标系
    World = 2, // 世界坐标系
};

// 交融类型
enum BlendType : int
{
    JointToJoint = 0,  // 关节运动与关节运动交融
    JointToLine = 1,   // 关节运动与直线运动交融
    JointToCircle = 2, // 关节运动与圆弧运动交融
    LineToJoint = 3,   // 直线与关节运动交融
    CircleToJoint = 4, // 圆弧与关节运动交融
};

class RtdeInputBuilder
{
public:
    virtual ~RtdeInputBuilder() = default;

    // 设置速度比例(rtde输入接口)
    // f: 百分比(0~1.)
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual void setSpeedFractionSlider(const double &f) = 0;

    // 关节空间位置周期同步运动
    // q: j1~j6关节角度（弧度）
    // @throw InvalidArgument 输入参数不合法的异常
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual void servoJoint(const std::vector<double> &q) = 0;

    // 笛卡尔空间位置周期同步运动
    // pose: 位置姿态(x,y,z,rx,ry.rz)
    // ref : 1-表示相对于工具端坐标系 其他-相对于基坐标系(默认值)
    // @throw InvalidArgument 输入参数不合法的异常
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual void servoCartesian(const std::vector<double> &pose,
                                const int &ref = 0) = 0;

    // 关节空间速度周期同步运动
    // qd: J1~J6的速度(rad/s)
    // a : 加速度
    // t : 函数返回的时间,（可选）,如果提供则该函数时间t后返回
    //                         如果不提供则在达到目标速度后返回
    // @throw InvalidArgument 输入参数不合法的异常
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual void speedJoint(const std::vector<double> &qd, const double &a,
                            const double &t) = 0;

    // 笛卡尔空间速度周期同步运动
    // xd: 工具端的速度(x,y,z,rx,ry,rz)(rad/s)
    // a : 工具端位置上的加速度(m/s^2)
    // t : 函数返回的时间
    // aRot:工具端转动加速度(可选)，如果没有定义，将使用a的位置加速度
    // @throw InvalidArgument 输入参数不合法的异常
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual void speedLine(const std::vector<double> &xd, const double &a,
                           const double &t, const double &aRot) = 0;

    // 设置标准数字输出(rtde输入接口)
    // maske: 批量设置的位
    // bits: 设置的数值
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual void setStandardDigitalOutput(const uint32_t &mask,
                                          const uint32_t &bits) = 0;
    // 设置可配置数字输出(rtde输入接口)
    // maske: 批量设置的位
    // bits: 设置的数值
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual void setConfigurableDigitalOutput(const uint32_t &mask,
                                              const uint32_t &bits) = 0;
    // 设置工具端数字输出(rtde输入接口)
    // maske: 批量设置的位
    // bits: 设置的数值
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual void setToolDigitalOutput(const uint32_t &mask,
                                      const uint32_t &bits) = 0;
    // 设置标准模拟输出(rtde输入接口)
    // index: 模拟量id
    // value: 设置的模拟量数值
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual void setStandardAnalogOutput(const int &index,
                                         const double &value) = 0;
    // 设置输入寄存器位: 0~31(rtde输入接口)
    // value: 0代表false,1代表true
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual void setBitRegisters0_31(const uint32_t &value) = 0;

    // 设置输入寄存器位: 32~63(rtde输入接口)
    // value: 0代表false,1代表true
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual void setBitRegisters32_63(const uint32_t &value) = 0;

    // 设置输入寄存器位: 64~127(rtde输入接口)
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual void setBitRegisters64_127(const uint64_t &value) = 0;

    // 设置int型寄存器(rtde输入接口)
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual void setIntRegisters(const std::vector<int> &value) = 0;

    // 设置double型寄存器(rtde输入接口)
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual void setDoubleRegisters(const std::vector<double> &value) = 0;

    // 将构造好的RTDE输入指令包发送到控制器软件
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual void send() = 0;
};

using RtdeInputBuilderPtr = std::shared_ptr<RtdeInputBuilder>;
class AuboDriverPrivate;

// AUBO机器人控制SDK接口类
// 这个类是一个纯虚类，它由一个工厂函数createAuboDriver创建，开放了用户在对AUBO机器人进行二次编程过程中所需的部分接口函数，
// 部分函数在调用之后会抛出异常，这些可能的异常在函数的注释中会有说明，用户在调用这些函数时注意对这些异常进行捕获，
// 否则在异常抛出时程序会直接退出, 当然，如果你本意就是想让程序在产生异常时退出,
// 那就可以不捕获它
//  1. 检查用户的输入参数不合法
//  2. 函数执行的前提条件没有达到, 例如在没有连接到服务器的情况下获取机器人相关
//     的一些状态信息
//  3. 函数执行出现非预期结果, 例如请求连接超时
//
// 注意:
// 在读取机器人相关信息时需要注意一点，机器人的配置信息在连接成功之后就可以读取，而机器人的状态信息则需要登录之后才能读取
//
class AuboDriver
{
public:
    virtual ~AuboDriver() = default;

    enum LogLevel
    {
        Info = 0,    // Informational.
        Warning = 1, // Warns about issues that, although not
                     // technically a problem now, could cause problems
                     // in the future. For example, a // warning will
                     // be printed when parsing a message that is near
                     // the message size limit.
        Error = 2,   // An error occurred which should never happen
                     // during normal use.
        Fatal = 3,   // An error occurred from which the library cannot
                     // recover.  This usually indicates a programming
                     // error in the code which calls the library,
                     // especially when compiled in debug mode.
    };

    // AuboDriver内部log处理方法原型
    // 可以这么定义:
    //
    // inline void MyLogHandler(const LogLevel &level, const std::string
    // &message)
    // {
    //    static const char *level_names[] = { "INFO", "WARNING", "ERROR",
    //    "FATAL" };
    //    fprintf(stderr, "[%s] %s\n", level_names[level], message.c_str());
    //    fflush(stderr);
    // }
    using InternalLogHandler =
        std::function<void(const LogLevel &level, const std::string &message)>;

    // AuboDriver内部会输出一些日志信息，通过setLogHandler可以设置AuboDriver内部log模块的处理函数
    // 传入参数为nullptr时, 内部日志将不会进行处理
    // 返回值为旧的处理函数
    virtual InternalLogHandler setInternalLogHandler(
        const InternalLogHandler &new_func) = 0;

    // 连接到服务器，可以设置超时等到时间
    // robot_ip:ip地址
    // port    :端口
    // timeout :超时时间，单位是毫秒(ms)
    // 返回值   :是否连接成功
    // @throw InvalidArgument 输入的超时时间不大于0
    virtual bool connectToServer(const std::string &robot_ip = "127.0.0.1",
                                 const int &port = 30001,
                                 const int &timeout = 50) = 0;

    virtual std::string getRobotHostAddress() const = 0;
    virtual int getRobotHostPort() const = 0;

    // 断开与服务器的连接
    // 如果已经登录, 则会自动登出
    virtual void disconnectFromServer() = 0;

    // 等待与服务器断开连接，这是一个阻塞函数
    // @throw NotConnected 还没有连接到服务器的异常
    virtual void waitForTerminate() = 0;

    // 登录到服务器
    // username: 用户名
    // password: 密码
    // timeout: 超时时间必须大于0
    // @throw InvalidArgument 输入参数不合法的异常
    // @throw NotConnected 还没有连接到服务器的异常
    virtual bool login(const std::string &username, const std::string &password,
                       const int &timeout = 5) = 0;

    // 注销登录
    // timeout: 登出请求超时时间
    // @throw InvalidArgument 输入参数不合法的异常
    // @throw NotConnected 还没有连接到服务器的异常
    virtual bool logout(const int &timeout = 5) = 0;

    // 获取本AuboDriver(本模块自身)的版本信息
    // 返回值: 格式为 <major version>.<minor version>.<reversion>.<short hash>
    virtual int32_t getAuboDriverVersion() const = 0;

    // 获取连接的控制器软件的版本信息
    // 返回值: 格式为 <major version>.<minor version>.<reversion>.<short hash>
    // @throw NotConnected 还没有连接到服务器的异常
    virtual int32_t getAuboControlVersion() const = 0;

    // 获取接口板固件版本信息
    // 返回值: 格式为 <major version>.<minor version>.<reversion>.<short hash>
    // @throw NotConnected 还没有连接到服务器的异常
    virtual int32_t getMasterBoardFirmwareVersion() const = 0;

    // 获取工具端固件版本号
    // 返回值: 格式为 <major version>.<minor version>.<reversion>.<short hash>
    // @throw NotConnected 还没有连接到服务器的异常
    virtual int32_t getToolFirmwareVersions() const = 0;

    // 获取工具端硬件版本号
    // 返回值: 格式为 <major version>.<minor version>.<reversion>.<short hash>
    // @throw NotConnected 还没有连接到服务器的异常
    virtual int32_t getToolHardwareVersions() const = 0;

    // 获取机械臂关节固件版本号
    // 返回值: 格式为 <major version>.<minor version>.<reversion>.<short hash>
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw ValueExpired 状态数据无效
    virtual std::vector<int32_t> getJointFirmwareVersions() const = 0;

    // 获取机械臂关节硬件版本号
    // 返回值: 格式为 <major version>.<minor version>.<reversion>.<short hash>
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw ValueExpired 状态数据无效
    virtual std::vector<int32_t> getJointHardwareVersions() const = 0;

    // 获取控制柜类型
    // 返回值: 控制柜版本字符串
    // @throw NotConnected 还没有连接到服务器的异常
    virtual std::string getControlBoxType() const = 0;

    // 获取机器人的类型, 具体类型参考RobotType
    // 返回值: RobotType枚举
    // @throw NotConnected 还没有连接到服务器的异常
    virtual RobotType getRobotType() const = 0;

    // 获取机器人DH参数
    // @throw NotConnected 还没有连接到服务器的异常
    virtual void getDhParameter(std::vector<double> &theta,
                                std::vector<double> &a, std::vector<double> &d,
                                std::vector<double> &alpha) = 0;

    // 获取控制器进程运行时间
    // return 控制器运行时间(秒)
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual double getAuboControlUptime() const = 0;

    // 机器人的年龄
    // return 机器人年龄(秒)
    // @throw NotConnected 还没有连接到服务器的异常
    virtual uint64_t getRobotAge() const = 0;

    // 机器人上电指令, 机器人本体通电
    // 返回值: 是否成功
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual bool setRobotPowerOn() = 0;

    // 机器人断电指令, 机器人本体断电,
    // 描述: 控制器软件在接收到断电指令之后会先抱死关节制动器，然后切断本体电源
    // 返回值: 是否成功
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual bool setRobotPowerOff() = 0;

    // 机器人运行指令, 控制器软件收到指令后会尝试将机器人的状态设置为运行状态,
    // 描述: 只有处于运行状态的机器人才能响应机器人运动相关控制指令
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual bool setRobotOperational() = 0;

    // 获取登陆的角色
    // 返回值: UserRole枚举类型
    virtual UserRole getLoginStatus() const = 0;

    // 设置操作模式, 可以参考OperationalMode定义
    // mode: Disabled,Automatic,Manual
    // 返回值: 是否设置成功
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual bool setOperationMode(const OperationalMode &mode) = 0;

    // 校准末端力矩传感器, 至少输入3组采样数据
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual bool calibrateTcpForceSensor(
        const std::vector<std::vector<double>> &force,
        const std::vector<std::vector<double>> &q, const int &timeout = 10) = 0;

    // 开始或者结束拖动示教
    // enable: true代表使能，false代表失能
    // 返回值: 是否设置成功
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual bool freedrive(const bool &enable) = 0;

    // 设置到真实机器人模式
    // 返回值: 是否设置成功
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual bool setReal() = 0;

    // 设置到仿真机器人模式
    // 返回值: 是否设置成功
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual bool setSim() = 0;

    // 设置TCP偏移
    // offset: x,y,z,rx,ry,rz偏移值
    // 返回值: 是否成功
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual bool setTcpOffset(const std::vector<double> &offset) = 0;

    // 开始程序运行
    // 返回值: 是否设置成功
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual bool setProgramRun() = 0;

    // 暂停程序运行
    // 返回值: 是否设置成功
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual bool setProgramPause() = 0;

    // 恢复暂停的程序运行
    // 返回值: 是否设置成功
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual bool setProgramResume() = 0;

    // 退出程序运行
    // 返回值: 是否设置成功
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual bool setProgramAbort() = 0;

    // 输出(注入)日志记录到控制器软件的日志系统
    // level: 等级
    // src  : 日志位置
    // message: 信息
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual void logToController(const LogLevel &level, const std::string &src,
                                 const std::string &message) = 0;

    // 获取程序行号
    // 返回值: 正在执行的行号
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual int getLineNumber() = 0;

    // 获取程序运行当前行的标签
    // 返回值: 返回正在执行的行的标签
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual std::string getLabelString() = 0;

    // 获取机器人脚本运行时全局变量值
    // name : 全局变量名字
    // value: 数值
    // 返回值:
    virtual int getVariable(const std::string &name, double &value) = 0;
    virtual int getVariable(const std::string &name, int &value) = 0;

    // 发起安全配置请求(控制器软件读取安全配置文件，自动配置)
    // 返回值: 是否配置成功
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual bool safetyConfirm() = 0;

    // 发起固件升级请求(控制器软件读取固件升级包，自动升级)
    // 返回值: 是否升级成功
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual bool firmwareUpdate() = 0;

    // 读取程序运行状态(rtde运行时主机接口)
    // 返回值: RuntimeState枚举
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual RuntimeState getProgramRunState() = 0;

    // 获取安全状态(rtde运行时主机接口)
    // 返回值: SafetyMode枚举
    // @throw NotConnect 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual SafetyMode getSafetyMode() const = 0;

    // 获取机器人安全状态, 参考SafetyModeStatus定义(rtde运行时主机接口)
    // 返回值: SafetyModeStatus枚举
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual SafetyModeStatus getSafetyModeStatus() const = 0;

    // 获取机器人状态位(rtde运行时主机接口)
    // 返回值: Bits 0-3:Is power on
    //                Is program running
    //                Is teach button pressed
    //                Is power button pressed
    // @throw NotConnect 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到副武器的异常
    virtual uint32_t getRobotStatusBits() const = 0;

    // 获取安全状态位(rtde运行时主机接口)
    // 返回值: Bits 0-10: Is normal mode,
    //                   Is reduced mode,
    //                   Is protective stopped,
    //                   Is recovery mode,
    //                   Is safeguard stopped ,
    //                   Is system emergency stopped,
    //                   Is robot emergency stopped,
    //                   Is emergency stopped ,
    //                   Is violation,
    //                   Is  fault,
    //                   Is stopped due to safety
    // @throw NotConnect 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到副武器的异常
    virtual uint32_t getSafetyStatusBits() const = 0;

    // 获取轨迹运行时速度比例因子(rtde运行时主机接口)
    // 返回值: 0~1之间的double类型数字
    // @throw NotConnect 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到副武器的异常
    virtual double getSpeedScaling() const = 0;

    // 获取目标速度比例因子(rtde运行时主机接口)
    // 返回值: 0~1之间的double类型数字
    // throw NotConnect 还没有连接到副武器的异常
    // throw NotLogin 还没有登录到服务的异常
    virtual double getTargetSpeedFraction() const = 0;

    // 获取机器人控制模式,可以参考RobotControlMode定义
    // 返回值: RobotControlMode枚举
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual RobotControlMode getRobotControlMode() const = 0;

    // 获取实时线程运行时间(rtde运行时主机接口)
    // 返回值: 单位是s
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual double getActualExecutionTime() const = 0;

    // 获取机器人运行状态(rtde运行时主机接口)
    // 返回值: RobotMode枚举
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual RobotMode getRobotMode() const = 0;

    // 获取机械臂自由度
    // 返回值: 连接的机械臂的自由度
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    // @throw ValueExpired 状态数据无效
    virtual int getRobotDof() const = 0;

    // 获取TCP偏移值
    // 返回值: [0]~[5]代表x,y,z,rx,ry,rz
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    // @throw ValueExpired 状态数据无效
    virtual std::vector<double> getTcpOffset() const = 0;

    // 获取机械臂各关节的状态(rtde关节数据接口)
    // 返回值: 每个关节的JointMode
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    // @throw ValueExpired 状态数据无效
    virtual std::vector<JointMode> getJointModes() const = 0;

    // 获取机械臂关节实际位置(弧度)(rtde关节数据接口)
    // 返回值: 每个关节的位置
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    // @throw ValueExpired 状态数据无效
    virtual std::vector<double> getJointPositions() const = 0;

    // 获取机械臂关节实际速度(弧度每秒)(rtde关节数据接口)
    // 返回值: 每个关节的速度
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    // @throw ValueExpired 状态数据无效
    virtual std::vector<double> getJointVelocities() const = 0;

    // 获取机械臂关节实际电流(安培)(rtde关节数据接口)
    // 返回值: 每个关节的电流
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    // @throw ValueExpired 状态数据无效
    virtual std::vector<double> getJointCurrents() const = 0;

    // 获取机械臂关节实际电压(伏特)(rtde关节数据接口)
    // 返回值: 每个关节的电压
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    // @throw ValueExpired 状态数据无效
    virtual std::vector<double> getJointVoltages() const = 0;

    // 获取机械臂关节实际力矩值(牛顿米)(rtde关节数据接口，缺少proto)
    // 返回值: 每个关节的力矩
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    // @throw ValueExpired 状态数据无效
    virtual std::vector<double> getJointTorques() const = 0;

    // 获取机械臂关节实际温度(摄氏度)(rtde关节数据接口)
    // 返回值: 每个关节的温度
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    // @throw ValueExpired 状态数据无效
    virtual std::vector<double> getJointTemperatures() const = 0;

    // 获取机械臂关节目标位置(弧度)(rtde关节数据接口)
    // 返回值: 每个关节的目标位置
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    // @throw ValueExpired 状态数据无效
    virtual std::vector<double> getJointTargetPositions() const = 0;

    // 获取机械臂关节目标速度(弧度/s)(rtde关节数据接口)
    // 返回值: 每个关节目标速度
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    // @throw ValueExpired 状态数据无效
    virtual std::vector<double> getJointTargetVelocities() const = 0;

    // 获取机械臂关节目标加速度(弧度/s^2)(rtde关节数据接口)
    // 返回值: 每个关节目标加速度
    // @throw Noeconnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    // ＠throw ValueExpired 状态数据无效
    virtual std::vector<double> getJointTargetAccelerations() const = 0;

    // 获取机械臂关节目标电流(mA)(rtde关节数据接口)
    // 返回值: 每个关节目标电流
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual std::vector<double> getJointTargetCurrents() const = 0;

    // 获取机械臂关节目标力矩(Nm)(rtde关节数据接口)
    // 返回值: 每个关节目标力矩
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual std::vector<double> getJointTargetTorques() const = 0;

    // 获取机械臂关节最小位置限制(弧度)
    // 返回值: 每个关节最小位置限制
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw ValueExpired 状态数据无效
    virtual std::vector<double> getJointMinPositionLimits() const = 0;

    // 获取机械臂关节最大位置限制(弧度)
    // 返回值: 每个关节最大位置限制
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw ValueExpired 状态数据无效
    virtual std::vector<double> getJointMaxPositionLimits() const = 0;

    // 获取机械臂关节最大速度限制(弧度/秒)
    // 返回值: 每个关节最大速度限制
    // @throw NotConnected 还没有连接到服务器的异常
    virtual std::vector<double> getJointMaxSpeedLimits() const = 0;

    // 获取机械臂关节最大加速度限制(弧度/秒^2)
    // 返回值: 每个关节最大加速度限制
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw ValueExpired 状态数据无效
    virtual std::vector<double> getJointMaxAccelerationLimits() const = 0;

    // 获取机械臂TCP位姿,
    // 长度的单位是米(m),角度单位是弧度(rad)(rtde工具中心点接口) 返回值:(x, y,
    // z, rx, ry, rz)
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    // @throw ValueExpired 状态数据无效，需要开启RTDE数据传输
    virtual std::vector<double> getTcpPose() const = 0;

    // 获取机械臂TCP速度,长度的单位是米(m/s),角度单位是弧度(rad/s)(rtde工具中心点接口)
    // 返回值: (x, y, z, rx, ry, rz)
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    // @throw ValueExpired 状态数据无效，需要开启RTDE数据传输
    virtual std::vector<double> getTcpSpeed() const = 0;

    // 获取机械臂TCP力/力矩(rtde工具中心点接口)
    // 返回值: (fx, fy, fz, tx, ty, tz)
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    // @throw ValueExpired 状态数据无效，需要开启RTDE数据传输
    virtual std::vector<double> getTcpForce() const = 0;

    // 获取目标TCP在笛卡尔空间下的坐标(rtde工具中心点接口)
    // 返回值: (x,y,z,rx,ry,rz)
    // @throw NotConnect 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务器的异常
    // @throw ValueExpired 状态数据无效，需要开启RTDE数据传输
    virtual std::vector<double> getTcpTargetPose() const = 0;

    // 获取目标TCP在笛卡尔空间下的速度,长度的单位是米(m/s),角度单位是弧度(rad/s)(rtde工具中心点接口)
    // 返回值: (x,y,z,rx,ry,rz)
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务器的异常
    // @throw ValueExpired 状态数据无效，需要开启RTDE数据传输
    virtual std::vector<double> getTcpTargetSpeed() const = 0;

    // 获取标准数字输入状态(rtde主接口板接口,缺少proto)
    // 返回值: vector大小是8
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual std::vector<bool> getStandardDigitalInput() const = 0;

    // 获取标准模拟输入状态(rtde主接口板接口)
    // 返回值: vector大小是2
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual std::vector<double> getStandardAnalogInput() const = 0;

    // 获取可配置数字输入状态(rtde主接口板接口,缺少proto)
    // 返回值: vector大小是2
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual std::vector<bool> getConfigurableDigitalInput() const = 0;

    // 获取可配置模拟输入状态(rtde主接口板接口,缺少proto)
    // 返回值: vector大小是2
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual std::vector<double> getConfigurableAnalogInput() const = 0;

    // 获取标准数字输出状态(rtde主接口板接口,缺少proto)
    // 返回值: vector大小是8
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual std::vector<bool> getStandardDigitalOutput() const = 0;

    // 获取标准模拟输出状态(rtde主接口板接口)
    // 返回值: vector大小是2
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual std::vector<double> getStandardAnalogOutput() const = 0;

    // 获取可配置数字输出状态(rtde主接口板接口,缺少proto)
    // 返回值: vector大小是2
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual std::vector<bool> getConfigurableDigitalOutput() const = 0;

    // 获取可配置模拟输出状态(rtde主接口板接口,缺少proto)
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual std::vector<double> getConfigurableAnalogOutput() const = 0;

    // 获取安全控制板主电压(rtde主接口板接口)
    // 返回值: double型
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务器的异常
    virtual double getMainVoltage() const = 0;

    // 获取主电源(48V/24V)电流值
    // 返回值: 电流值
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual double getMainCurrent() const = 0;

    // 获取三段开关状态
    // 返回值: uint32_t
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual uint32_t getThreePositionButtonStatus() const = 0;

    // 获取控制柜温度
    // 返回值: 温度
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual double getControlboxTemperature() const = 0;

    // 获取机械臂本体电压值(伏特)(rtde主接口板接口)
    // 返回值: 电压值
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual double getRobotVoltage() const = 0;

    // 获取机械臂本体总电流(安培)(rtde主接口板接口)
    // 返回值: 电流值
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual double getRobotCurrent() const = 0;

    // 获取主板IO电流(安培)(rtde主接口板接口)
    // 返回值: 电流值
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual double getMasterIoCurrent() const = 0;

    // 获取注塑机接口电压(伏特)(rtde主接口板接口)
    // 返回值: 电压值
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual double getEuromap67Voltage() const = 0;

    // 获取注塑机接口电流(安培)(rtde主接口板接口)
    // 返回值: 电流值
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual double getEuromap67Current() const = 0;

    // 获取工具端总电压(伏特)(rtde工具端接口)
    // 返回值: 工具端电压
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual double getToolVoltage() const = 0;

    // 获取工具端总电流(安培)(rtde工具端接口)
    // 返回值: 工具端电流
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual double getToolCurrent() const = 0;

    // 获取工具端温度
    // 返回值: 工具端温度
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual double getToolTempture() const = 0;

    // 获取工具总电流(安培)(rtde工具端接口)
    // 返回值: 电流
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual double getIoCurrent() const = 0;

    // 获取工具端数字输入状态(rtde工具端接口,缺少proto)
    // 返回值: vector大小是2
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual std::vector<bool> getToolDigitalInput() const = 0;

    // 获取工具端模拟输入状态(rtde工具端接口,缺少proto)
    // 返回值: vector大小是2
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual std::vector<double> getToolAnalogInput() const = 0;

    // 获取工具端数字输出状态(rtde工具端接口,缺少proto)
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual std::vector<bool> getToolDigitalOutput() const = 0;

    // 获取工具端模拟输出状态(rtde工具端接口,缺少proto)
    // 返回值: vector大小是2
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual std::vector<double> getToolAnalogOutput() const = 0;

    // 获取输出寄存器0~63状态(rtde寄存器输出接口)
    // 返回值:
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual uint64_t getBitOutputRegister0_63() const = 0;

    // 获取输出寄存器64~127状态(rtde寄存器输出接口)
    // 返回值:
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual uint64_t getBitOutputRegister64_127() const = 0;

    // 获取int类型输出寄存器状态(rtde寄存器输出接口)
    // 返回值:
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual std::vector<uint32_t> getIntOutputRegister() const = 0;

    // 获取double类型输出寄存器状态(rtde寄存器输出接口)
    // 返回值:
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual std::vector<double> getDoubleOutputRegister() const = 0;

    // 获取输入寄存器0~63状态(rtde寄存器输出接口)
    // 返回值:
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual uint64_t getBitInputRegister0_63() const = 0;

    // 获取输入寄存器64~127状态(rtde寄存器输出接口)
    // 返回值:
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual uint64_t getBitInputRegister64_127() const = 0;

    // 获取int类型输入寄存器状态(rtde寄存器输出接口)
    // 返回值:
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual std::vector<uint32_t> getIntInputRegister() const = 0;

    // 获取double类型输入寄存器状态(rtde寄存器输出接口)
    // 返回值:
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual std::vector<double> getDoubleInputRegister() const = 0;

    // 获取RTDE输入(相对于服务器而言)字段列表
    virtual std::map<std::string, std::string> getRtdeInputList() const = 0;

    // 获取RTDE输出(相对于服务器而言)字段列表
    virtual std::map<std::string, std::string> getRtdeOutputList() const = 0;

    // 设置RTDE输出(相对于服务器而言)字段菜单
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual bool setRtdeOutputRecipe(const uint8_t &recipe_id,
                                     const std::vector<std::string> &names,
                                     const double &frequency) = 0;

    // 开始指定编号的RTDE输出传输，可以设置一个回调函数
    // 设置回调函数可以捕获所有的实时数据,
    // 注意不要在回调函数中进行耗时操作或者阻塞操作
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual bool startRtdeTransmission(
        const uint8_t &recipe_id,
        const std::function<void(void)> &cb = std::function<void(void)>()) = 0;

    // 同步最新一次RTDE输出(等待接收到输出数据包)
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual void syncRtdeTransmission(const uint8_t &recipe_id,
                                      const int &timeout) = 0;

    // 暂停指定编号的RTDE输出传输
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual bool pauseRtdeTransmission(const uint8_t &recipe_id) = 0;

    // 获取RTDE输入数据包builder, 用来构建和发送服务器RTDE输入数据包
    // 返回值：RtdeInputBuilderPtr类型指针，用于访问RtdeInputBuilder类型的对象
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual RtdeInputBuilderPtr getRtdeInputBuilder() = 0;

    // 下载脚本到服务器
    // string_or_path:脚本字符串或者脚本路径
    // 返回值:
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual int downloadScript(const std::string &string_or_path) = 0;

    // 从服务器上传正在运行的脚本
    // 返回值:正在运行的脚本字符串
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual std::string uploadScript() = 0;

    // 设置脚本编译输出信息回调函数
    // 回调函数类型:void
    // timestamp:时间戳
    // line_number :行号
    // colum_number:列号
    // msg         :编译信息
    virtual void setCompileMessageHandler(
        const std::function<
            void(const double &timestamp, const int &line_number,
                 const int &colum_number, const std::string &msg)> &cb) = 0;

    // 设置异常消息处理回调函数
    // 回调函数类型:void
    // timestamp:时间戳
    // line_number :行号
    // colum_number:列号
    // msg         :异常信息
    virtual void setExceptionMessageHandler(
        const std::function<void(double &timestamp, const int &line_number,
                                 const int &colum_number,
                                 const std::string &msg)> &cb) = 0;

    // 设置text消息处理回调函数
    // 回调函数类型:void
    // timestamp:时间戳
    // src         :信息发出位置
    // msg         :信息
    virtual void setTextMessageHandler(
        const std::function<void(const double &timestamp, const uint8_t &src,
                                 const std::string &msg)> &cb) = 0;

    //
    virtual void setCommMessageHandler(
        const std::function<void(
            const double &timestamp, const uint8_t &src,
            const int &robotMessageCode, const int &robotMessageArgument,
            const SafetyMode &safety_mode, const uint32_t &report_data_type,
            const uint32_t &report_data)> &cb) = 0;

    // 设置安全消息接收处理回调函数，注意不要在回调函数中做耗时操作
    // 回调函数类型
    // timestamp:时间戳
    // src:信息出处
    // robotMessageCode:机器人消息代码
    // robotMessageArgument:机器人消息参数
    // safety_mode:安全模式的具体值
    // report_data_type:报告的数据类型
    // report_data:报告的数据
    virtual void setSafetyMessageHandler(
        const std::function<void(
            const double &timestamp, const uint8_t &src,
            const int &robotMessageCode, const int &robotMessageArgument,
            const SafetyMode &safety_mode, const uint32_t &report_data_type,
            const uint32_t &report_data)> &cb) = 0;

    // 发送离线轨迹到控制器并执行，离线轨迹可以通过拖动示教录制或者仿真软件生成
    // q:J1~J6关节角度（弧度）
    // 返回值：
    // finished:是否完成后函数再返回
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual int moveTopp(const std::vector<double> &q,
                         const bool &finished = false) = 0;

    // 关节空间运动
    // q:J1~J6关节角度（弧度）
    // 返回值：运动id
    // @throw InvalidArgument 输入参数不合法的异常
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual int moveJoint(const std::vector<double> &q, const double &a,
                          const double &v) = 0;

    // 笛卡尔空间直线运动
    // pose:(x,y,z,rx,ry,rz)
    // a:直线加速度
    // v:直线速度
    // aRot:旋转加速度
    // 返回值：
    // @throw InvalidArgument 输入参数不合法的异常
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual int moveLine(const std::vector<double> &pose, const double &a,
                         const double &v, const double &aRot) = 0;

    // 关节空间停止运动
    // a:停止加速度(rad/s^2)
    // 返回值：
    // @throw InvalidArgument 输入参数不合法的异常
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual int stopJoint(const double &a) = 0;

    // 笛卡尔空间停止运动
    // a:停止加速度(rad/s^2)
    // aRot:停止时旋转的加速度(rad/s^2)
    // 返回值：
    // @throw InvalidArgument 输入参数不合法的异常
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual int stopLine(const double &a, const double &aRot) = 0;

    // 示教运行关节运动(最大速度/加速度有限制)
    // joint:关节id
    // speed:速度(rad/s)
    // acc:加速度(rad/s^2)
    // 返回值：
    // @throw InvalidArgument 输入参数不合法的异常
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual int jogJoint(const int &joint, const double &speed,
                         const double &acc) = 0;

    // 示教运行直线运动(最大速度/加速度有限制)
    // direction:±1->x,±2->y,±3->z,±4->rx,±5->ry,±6->rz
    // CoordType:坐标系
    // speed:速度
    // add:加速度
    // 返回值：
    // @throw InvalidArgument 输入参数不合法的异常
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual int jogLine(const int &direction, const CoordType &coord_slect,
                        const double &speed, const double &acc) = 0;

    // 示教运行停止(最大速度/加速度有限制)
    // acc:停止加速度
    // 返回值：
    // @throw InvalidArgument 输入参数不合法的异常
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual int jogStop(const double &acc) = 0;

    // 等待机械臂停止运动
    // motion_id:运动id
    // timeout为等待时间(毫秒), -1表示无限等待
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual void waitForMotionComplete(const int &motion_id,
                                       const int &timeout) = 0;

    // 分析表达式是否正确(类似于编译)
    virtual std::string analyseExpression(const std::string &expression) = 0;

    // 获取负载值
    // 返回值：末端负载
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual double getPayloadMass() = 0;

    // 机器人是否安装正确
    // 返回值:
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual bool isRobotMountingCorrect() = 0;

    // 运动学正解
    // q:J1~J6关节弧度
    // 返回值:(x,y,z,rx,ry,rz)
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual std::vector<double> getForwardKinematics(
        const std::vector<double> &q) = 0;

    // 运动学逆解
    // x:目标点(x,y,z,rx,ry,rz)
    // qnear:参考点（可以选择为零点或者当前点）
    // eps:
    // 返回值：J1～J6关节弧度
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual std::vector<double> getInverseKinematics(
        const std::vector<double> &x, const std::vector<double> &qnear,
        const double &eps = 1e-6) = 0;

    // 计算轨迹点
    // q0表示路径的起点, q1表示路径的终点， r表示q1处的交融半径,
    // step表示采样步进长度
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual std::vector<std::vector<double>> getPathJoint(
        const std::vector<double> &q0, const double &r,
        const std::vector<double> &q1, const double &step) = 0;

    // 计算轨迹点（带交融）
    // q_start交融路径第一段的起始点
    // q_via交融点
    // q_to第二段路径的终点
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual std::vector<std::vector<double>> getPathBlend(
        const BlendType &type, const std::vector<double> &q_start,
        const std::vector<double> &q_via, const double &r,
        const std::vector<double> &q_to, const double &step) = 0;

    // 坐标变换
    // T_world->to = T_world->from * T_from->to
    // T_x->to = T_x->from * T_from->to
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual std::vector<double> poseTrans(
        const std::vector<double> &pose_from,
        const std::vector<double> &pose_from_to) = 0;

    // 从控制器上传文件
    virtual bool uploadFile(const std::string &remote_file,
                            const std::string &path,
                            const bool &block = true) = 0;

    // 传输文件到控制器
    virtual bool downloadFile(const std::string &file,
                              const std::string &remote_path,
                              const bool &block = true) = 0;
    // 欧拉角转四元数
    // rpy :绕固定坐标系XYZ转动，单位rad
    // 返回值:单位四元数，Hamilton顺序
    // @throw InvalidArgument输入参数不合法的异常
    virtual std::vector<double> getRpyTransQuat(
        const std::vector<double> &rpy) = 0;

    // 四元数转欧拉角
    // quat:单位四元数，Hamilton顺序
    // 返回值:欧拉角,绕固定坐标系XYZ转动，单位rad
    // throw InvalidArgument输入参数不合法的异常
    virtual std::vector<double> getQuatTranRpy(
        const std::vector<double> &quat) = 0;

    // 获取内部使用接口
    // @throw NotConnected 还没有连接到服务器的异常
    // @throw NotLogin 还没有登录到服务的异常
    virtual AuboDriverPrivate *getAuboDriverPrivate() = 0;
};

// 创建aubo_driver实例，需要指定aubo_control的IP地址以及各个端口号
// 如果地址输入不正确，或者端口号超出范围，程序将直接崩溃
// 成功返回AuboDirver指针，否则返回nullptr
/*!
\return AuboDirver指针
*/
extern ARCS_EXPORT AuboDriver *createAuboDriver();

} // namespace aubo_driver
} // namespace arcs

#endif // AUBO_DRIVER_H
