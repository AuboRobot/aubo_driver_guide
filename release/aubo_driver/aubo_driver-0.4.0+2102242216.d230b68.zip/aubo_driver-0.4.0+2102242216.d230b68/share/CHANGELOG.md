# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.4.0]

  * 增加rtde RunTimeMachine接口和寄存器接口，更改关节版本接口返回类型为int32,不再向前兼容

## [0.3.3]

  * 整理依赖关系(aubo_proto&protobuf)

## [0.3.2]

  * 增加download/uploadFile接口 

## [0.3.1]

  * debug版本库输出

## [0.3.0] 

  * socket通讯替换为udp(hp-socket实现) 

## [0.2.0] 

  * socket通讯替换为udp(hp-socket实现) 

## [0.3.0] 

  * logger依赖libcstone
  * 增加AuboDriverPrivate内部使用接口并实现了
      * setKinematicsParams
      * setDynamicsParams
      * setJointFrictionModel
      * setHandGuideParams 
      * getRobotHostAddress
      * getRobotHostPort

## [0.1.3] 

  * 对libcstone/aubo_proto的依赖关系修复
  * 增加 gitlab-ci支持
  * ProtobufDispatcher改为多实例(在一个程序中连接多个机器人)
  * RTDE output数据包进一步解析
  * servoCartesian增加ref参数(指示参考的坐标系) 

## [0.1.2] 

  * 增加syncRtdeTransmission接口
  * RtdeInputBuilder发送之后自动清空
  * 增加力传感器辨识工具(基于溧航的算法库)
  * 离线轨迹运行工具优化 

## [0.1.1] 

  * ip/port参数改由connectToServer函数传递
  * 增加Tcp偏移设置和读取的接口
  * 实现logToController接口
  *  

## [0.1.0] 

  * 实现基础SDK接口
  * python绑定实现
  * 基于auboserver进行测试 

