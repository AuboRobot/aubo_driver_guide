// Copyright 2020 Aubo Robotics
// License: All rights reserved by Aubo Robotics.
// Author: Lou Wei(louwei@aubo-robotics.cn)
// Maintainer:
//
#ifndef AUBO_DRIVER_EXCEPTIONS_H
#define AUBO_DRIVER_EXCEPTIONS_H

#include <chrono>
#include <stdexcept>
#include <sstream>

namespace arcs {
namespace aubo_driver {
/*!
 * \brief Our base class for exceptions. Specialized exceptions should inherit
 * from those.
 */
class ExceptionBase : virtual public std::runtime_error
{
public:
    ExceptionBase() : std::runtime_error("") {}
    explicit ExceptionBase(const std::string &what_arg)
        : std::runtime_error(what_arg)
    {
    }
    explicit ExceptionBase(const char *what_arg) : std::runtime_error(what_arg)
    {
    }

    virtual ~ExceptionBase() = default;

private:
    /* data */
};

class NotConnected : public ExceptionBase
{
public:
    NotConnected()
        : std::runtime_error("You should connect into aubo_control firstly")
    {
    }
};

class NotLogin : public ExceptionBase
{
public:
    NotLogin()
        : std::runtime_error("You should login into aubo_control firstly")
    {
    }
};

/*!
 * \brief A specialized exception representing detection of a not supported UR
 * control version.
 */
class VersionDismatch : public ExceptionBase
{
public:
    VersionDismatch() : VersionDismatch("", 0, 0) {}
    VersionDismatch(const std::string &text, const uint32_t version_req,
                    const uint32_t version_actual)
        : std::runtime_error(text)
    {
        version_required_ = version_req;
        version_actual_ = version_actual;
        std::stringstream ss;
        ss << text << "(Required version: " << version_required_
           << ", actual version: " << version_actual_ << ")";
        text_ = ss.str();
    }
    virtual ~VersionDismatch() = default;

    virtual const char *what() const noexcept override { return text_.c_str(); }

private:
    uint32_t version_required_;
    uint32_t version_actual_;
    std::string text_;
};

/*!
 * \brief A specialized exception representing that communication to the tool is
 * not possible.
 */
class ToolCommNotAvailable : public VersionDismatch
{
public:
    ToolCommNotAvailable() : ToolCommNotAvailable("", 0, 0) {}
    ToolCommNotAvailable(const std::string &text, const uint32_t version_req,
                         const uint32_t version_actual)
        : std::runtime_error(text),
          VersionDismatch(text, version_req, version_actual)
    {
    }
};

/*!
 * \brief A specialized exception representing that communication to the tool is
 * not possible.
 */
class TimeoutException : public ExceptionBase
{
public:
    TimeoutException() = delete;
    TimeoutException(const std::string &text, timeval timeout)
        : std::runtime_error(text)
    {
        std::stringstream ss;
        ss << text
           << "(Configured timeout: " << timeout.tv_sec + timeout.tv_usec * 1e-6
           << " sec)";
        text_ = ss.str();
    }
    virtual const char *what() const noexcept override { return text_.c_str(); }

private:
    std::string text_;
};

class InvalidArgument : public std::exception
{
public:
    InvalidArgument(const std::string &message) : message_(message) {}
    virtual ~InvalidArgument() throw() {}

    virtual const char *what() const throw() { return message_.c_str(); }

private:
    const std::string message_;
};

class ValueExpired : public ExceptionBase
{
public:
    ValueExpired() = delete;
    ValueExpired(const std::string &value) : std::runtime_error(value)
    {
        std::stringstream ss;
        ss << value << " unavailable.";
        text_ = ss.str();
    }
    virtual const char *what() const noexcept override { return text_.c_str(); }

private:
    std::string text_;
};

} // namespace aubo_driver
} // namespace arcs

#endif
